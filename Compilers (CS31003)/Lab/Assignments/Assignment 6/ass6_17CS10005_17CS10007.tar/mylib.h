/************************************************
Name -	Anshul Choudhary (17CS10005),
		Ayush Kumar (17CS10007)
Assignment No. - 6 (Target Code Generation)
************************************************/


#ifndef _MYLIB_H
#define _MYLIB_H
#define ERR 1
#define OK 0

int printStr(char *);
int readInt(int *eP);
int printInt(int);

#endif
