/******************************* 
Name - Anshul Choudhary
Roll No - 17CS10005
Assignment - 4 (Parser for tinyC)
********************************/

int main () { 
  int p,i,n,k;
  char strin[] = "Hello Rohan";
  char singlech = 'p';
  float val = 323.23;
  for (i=1;i<100;i++) {
    if(val<500) {
      printf ("%s",c);
    }
  }
  // Program to print area of rectangle
  int person=101,a,b;
  printf("Enter the length and breadth of rectangle: \n");
  scanf("%d%d",&a,&b);
  printf("Area of rectangle is: %d",a*b);
  return;
}