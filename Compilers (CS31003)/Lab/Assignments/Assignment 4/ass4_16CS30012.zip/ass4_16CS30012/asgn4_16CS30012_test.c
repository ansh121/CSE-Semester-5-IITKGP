// Test file

/* 
Name:- Ishwarkar Rohan Shankar
Roll No:- 16CS30012
Assignment 4 Compilers Lab
Autumn Semester 2018
*/


// Checks for all errors
// Try to make errors here and they will be detected

int main () { 
  int p,i,n,k;
  char strin[] = "Hello Rohan";
  char singlech = 'p';
  float val = 323.23;
  for (i=1;i<100;i++) {
    if(val<500) {
      printf ("%s",c);
    }
  }
  // Program to print area of rectangle
  int person=101,a,b;
  printf("Enter the length and breadth of rectangle: \n");
  scanf("%d%d",&a,&b);
  printf("Area of rectangle is: %d",a*b);
  return;
}