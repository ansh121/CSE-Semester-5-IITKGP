/*
Name:- Anshul Choudhary - Ayush Kumar
Roll No:- 17CS10005 - 17CS10007
Compilers Assignment 5
*/

//DANCING DOLL code
//to check various conditional, expression, function and declaration functionalities


void our()
{
int i;
for(i=0 ;i<=3999;i+=2)
{
if(i>='A'&& i<='Z')
  i=32+i;
  else
  if(i>='a'&& i<='z')
  i=32;
}
(prev)();
}

void main()
{
int far,p;
p=36;
p=our();
}